<?php
/**class validation  */
class Validator {  

   /**
    * check only string function validation
    *
    * @param $string
    * @return bool
    */
    private function stringChecker($string) {
        if (!preg_match("/^[a-zA-Z ]*$/", $string) === true) {
            return true;
        }
        return false;
    }

    /**
     *
     * @param array $data
     * @return bool or array
     */
    public function check($data, $EmailPassword = null) {

        $error = [];

        // check first name
        if (!empty($data['fname'])) {
            if ($this->stringChecker($data['fname'])) {
                $error['fname'] = "Only string is a valid first name.";
            }
        } else {          
            $error['fname'] = "Plese enter first name." ;
        }

        // check last name
        if (!empty($data['lname'])) {
            if ($this->stringChecker($data['lname'])) {
                $error['lname'] = "Only string is a valid last name.";
            }
        } else {
            $error['lname'] = "Plese enter last name." ;
        }

        //   check email
        if (!empty($data['email'])) {
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $error['email'] = "Invalid email format.";
            }
            if(isset($EmailPassword)) {
                while ($email = $EmailPassword->fetch_assoc()) {
                    if($email['email'] == $data['email']) {
                        $error['email'] = "This email is already exist.";
                    }
                }
            }

        }else {
            $error['email'] = "plese enter email.";
        }
        

        //  check password
        if (!empty($data['password'])) {

            if (strlen($data['password']) < '8') {
                $error['password'] = "Your password must contain at least 8 characters!.";
            } else if ( !preg_match("#[0-9]+#", $data['password']) ) {
                $error['password'] = "Your password must contain At least 1  number!.";
            } else if (!preg_match("#[A-Z]+#",$data['password'])) {
                $error['password'] = "Your password must contain at least 1 capital letter!.";
            } else if(!preg_match("#[a-z]+#",$data['password'])) {
                $error['password'] = "Your password must contain at least 1 lowercase letter!.";
            }
        } else {
            $error['password'] = "Please enter password.";
        }

       //conform password
        if (!empty($data['conform'])) {
            if ($data['conform'] != $data['password']) {
               $error['conform'] = "Plese conform password.";
            }
        } else {
         $error['conform'] = "Plese enter pasword.";
        }

        //  check date 
         if(!empty($data['dob'])){

            $dateToday = date("Y-m-d");
            $today = array_reverse(explode('-',$dateToday));
            $userDate = array_reverse(explode('-',$data['dob']));
            
           
            if($userDate[2] <= $today[2]){
                if(($userDate[2] == $today[2]) ? ($userDate[1] <= $today[1]) : true){
                    if(($userDate[1] == $today[1]) ? ($userDate[0] < $today[0]) : true){
                      
                    } else {
                        $error['dob'] = "Invalide date."; 
                    }
                } else {
                    $error['dob'] = "Invalide date."; 

                }
               
            }  else {
                $error['dob'] = "Invalide date."; 

            }
            
           

         } else {
            $error['dob'] = "Please enter date of birth.";
         }

        //  check gender
        if(empty($data['gender'])){
            $error['gender'] = "Please select gender.";
        }

        //  check phone number
        if(!empty($data['phone'])) {  
           if (!preg_match('/^[0-9]{10}+$/', $data['phone'])) {
               $error['phone'] = "Your mobile number must contain at least 10 characters!.";
            }
        } else {
            $error['phone'] = " Plese enter phone number.";
        }

        // check country
        if(($data['country'] == null)) {
            $error['country'] = "Please select country";
        }
        // check state
        if(($data['state'] == null)) {
            $error['state'] = "Please select state";
        }
        
        // check city
        if(($data['city'] == null)){
            $error['city'] = "Plese select city.";
            
        }

        //check tems and condition 
        if(empty($data['terms'])){
           $error['terms'] = "Agree terms and condition.";
        }

        if (empty($error)) {
            return true;
        } else {
            return $error;
        }
    }


    public function checkUserPassword($data) {
        $error = [];

        // check curent password
        if (!empty($data['password'])) {
            if (!password_verify($data['password'], $_SESSION['user']['password'] )){
                $error['password'] = "Please enter current password!.";
            } 
        } else {
            $error['password'] = "Please enter current password.";
        }

        // check new password
        if (!empty($data['newpassword'])) {

            if (strlen($data['newpassword']) < '8') {
                $error['newpassword'] = "Your password must contain at least 8 characters!.";
            } else if ( 
                !preg_match("#[0-9]+#", $data['password']) &&
                !preg_match("#[A-Z]+#", $data['password']) &&
                !preg_match("#[a-z]+#", $data['password'])
            ) {
                $error['newpassword'] = "Uparecase, lowercase, and number enter password!.";
            } 
        } else {
            $error['newpassword'] = "Please enter new password.";
        }

        //conform password
        if (!empty($data['conform'])) {
            if ($data['conform'] != $data['newpassword']) {
               $error['conform'] = "Plese conform enter password.";
            }
        } else {
         $error['conform'] = "Plese enter conform pasword.";
        }

         //check tems and condition 
         if(empty($data['terms'])){
            $error['terms'] = "Agree terms and condition.";
         }
        return $error;
    }


}
?>