<?php

include "Database.php";

/**
 * class user extends database class 
 */
class User extends Database {

    /**
     * insert data from database
     * @param [string] $table
     * @param [array] $field
     * @return bool;
     */
    public function register($field, $adduser = null) {
        $pass = password_hash($field['password'], PASSWORD_DEFAULT);
        $sql = "INSERT INTO users(fname, lname, email, password, dob, gender, mobile, country_id, state_id, city_id)VALUES('$field[fname]', '$field[lname]', '$field[email]', '$pass', '$field[dob]', '$field[gender]', '$field[phone]', '$field[country]', '$field[state]', '$field[city]')";
        $res = $this->conn->query($sql);
        if ($res) {
            if(isset($adduser)) {
                header('location:dashboard.php');
            } else {
                header('location:login.php');
            }
        }
    }

    /**
     * login user function
     * @param [array] $data
     * @return bool
     */
    public function login($data) {
        $sql = "SELECT * FROM users WHERE email = '".$data['email']."'";
        $res = $this->conn->query($sql);
        $row = $res->fetch_assoc();
        $pass = $row['password'];
        if(password_verify($data['password'], $pass) && $row['email'] == $data['email']) {
            $_SESSION['user'] = $row;
            return true;
        } else {
            return false;
        }   
    }

    /**
     * listing users dasebord
     *
     * @return userList
     */
    public function listingUser() {
        $sql = "SELECT * FROM users";
        $res = $this->conn->query($sql);
        return $res;
    }

    /**
     * delete user function
     * @param string $data
     * @return bool
     */
    public function delete($data) {
        $loginUser = $_SESSION['loginEmail'];
        $result = $this->conn->query("SELECT * FROM users WHERE id = '$data'");
        $row = $result->fetch_assoc();
        if($loginUser != $row['email']) {
            $sql = "DELETE FROM users WHERE id = '$data'";
            $res = $this->conn->query($sql);
        }
    }

    /**
     * update time user data get function
     *
     * @param [string] $id
     * @return array
     */
    public function userData($id) {
        $sql = "SELECT * FROM users WHERE id = '".$id['id']."'";
        $res = $this->conn->query($sql);
        $row = $res->fetch_assoc();
        if($row) {
            return $row;
        }
    }

    /**
     * update user function
     *
     * @param [string] $id
     * @param [array] $data
     * @return void
     */
    public function updateUser($id, $data) {

        $sql = "UPDATE users SET fname = '".$data['fname']."', lname = '".$data['lname']."', email = '".$data['email']."', dob = '".$data['dob']."', gender = '".$data['gender']."', mobile = '".$data['phone']."', country_id = '".$data['country']."', state_id = '".$data['state']."', city_id = '".$data['city']."' WHERE id =".$id."";

        $res = $this->conn->query($sql);
        
        return true;
    }

    /**
     *update user password function
     *
     * @return bool
     */
    public function updateUSerPassword($password) {
        $id = $_SESSION['user']['id'];
        $pass = password_hash($password['newpassword'],PASSWORD_DEFAULT);
       
        $sql = "UPDATE users SET password = '$pass' WHERE id = $id ";

        $res = $this->conn->query($sql);

        if($res) {
            header('location:dashboard.php');
        }
        

    }

    

    /**
     * state name get database state table function
     *
     * @return object
     */
    public function state($id) {
        $sql = "SELECT * FROM states WHERE id = '$id'";
        $res = $this->conn->query($sql);
        return $res;
    }

    /**
     * city name get database city table function
     *
     * @return object
     */
    public function city() {
        $sql = "SELECT * FROM city";
        $res = $this->conn->query($sql);
        return $res;
    }

}
?>